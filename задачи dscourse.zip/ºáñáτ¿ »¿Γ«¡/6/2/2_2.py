import pandas as pd
import json

with open('peoples.json') as f:
    peoples = json.load(f)
    
print(peoples['heights'].values.max())

def get_biggest_num(data):
          biggest_num = max(data, key=lambda x: x['heights'])
          return biggest_num

result = get_biggest_num(rows)
print (result)