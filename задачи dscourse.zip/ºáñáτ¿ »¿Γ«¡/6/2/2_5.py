import pandas as pd
import numpy as np
import json

with open('peoples.json') as f:
    peoples = json.load(f)
    
#print(peoples['gender'].values())

uniq = np.unique(list(peoples['gender'].values()))
print('Уникальные значения [gender]:', uniq)