import pandas as pd
import numpy as np
import json

with open('peoples.json') as f:
    peoples = json.load(f)
    
#print(peoples['heights'].values())


ma = max(peoples['heights'].values())
print('Максимальное [heights]:', ma)

mi = min(peoples['heights'].values())
print('Минимальное [heights]:', mi)

mean = np.array(list(peoples['heights'].values())).mean()
print('Среднее [heights]:', mean)

med = np.median(list(peoples['heights'].values()))
print('Медиана [heights]:', med)

ma1 = max(peoples['weights'].values())
print('Максимальное [weights]:', ma1)

mi1 = min(peoples['weights'].values())
print('Минимальное [weights]:', mi1)

med1 = np.median(list(peoples['weights'].values()))
print('Медиана [weights]:', med1)

mean1 = np.array(list(peoples['weights'].values())).mean()
print('Среднее [weights]:', mean1)

ma2 = max(peoples['ages'].values())
print('Максимальное [ages]:', ma2)

mi2 = min(peoples['ages'].values())
print('Минимальное [ages]:', mi2)

med2 = np.median(list(peoples['ages'].values()))
print('Медиана [ages]:', med2)

mean2 = np.array(list(peoples['ages'].values())).mean()
print('Среднее [ages]:', mean2)
