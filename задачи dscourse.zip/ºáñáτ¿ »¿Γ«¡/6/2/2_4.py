import pandas as pd
import numpy as np
import json

with open('peoples.json') as f:
    peoples = json.load(f)

kvar = np.percentile(list(peoples['heights'].values()), 75, interpolation='higher') - np.percentile(list(peoples['heights'].values()), 25, interpolation='lower')
print('Межквартильное расстояние [heights]:', kvar)

kvar1 = np.percentile(list(peoples['weights'].values()), 75, interpolation='higher') - np.percentile(list(peoples['weights'].values()), 25, interpolation='lower')
print('Межквартильное расстояние [weights]:', kvar1)

kvar2 = np.percentile(list(peoples['ages'].values()), 75, interpolation='higher') - np.percentile(list(peoples['ages'].values()), 25, interpolation='lower')
print('Межквартильное расстояние [ages]:', kvar2)