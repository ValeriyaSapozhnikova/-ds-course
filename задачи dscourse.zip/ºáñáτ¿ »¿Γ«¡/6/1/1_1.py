import matplotlib.pyplot as plt
import pandas as pd

df = pd.read_csv('E:/Питон/6 глава/1/iris.csv')
print(df.head(10))

print(df.info())

#DF = newdf.loc[newdf['species']=iris-setosa]
#print(len(DF))

