import matplotlib.pyplot as plt
import pandas as pd

df = pd.read_csv('iris-setosa.csv')

print(df)

header = ['sepal_len', 'sepal_wd']
df = pd.DataFrame(columns = header)
df.plot(kind = 'scatter',
        x = 'sepal_len',
        y = 'sepal_wd',
        title = 'sepal_len/sepal_wd')
plt.show()