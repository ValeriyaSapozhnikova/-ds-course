import matplotlib.pyplot as plt
import pandas as pd

df = pd.read_csv('iris.csv')
#print(df.head(10))

var_flower = {'iris-setosa':0, 'iris-versicolor':1, 'iris-virginica':2}

df['species'] = df['species'].map(var_flower)

#print(df)
df_1 = df.loc[df['species'] == 0]
print(df_1)

df_1.to_csv('iris-setosa.csv')
df_1.to_csv('iris-setosa.xls')
df_1.to_csv('iris-setosa.txt', sep = ',')

df_2 = df.loc[df['species'] == 1]
print(df_2)

df_2.to_csv('iris-versicolor.csv')
df_2.to_csv('iris-versicolor.xls')
df_2.to_csv('iris-versicolor.txt', sep = ',')

df_3 = df.loc[df['species'] == 2]
print(df_3)

df_3.to_csv('iris-virginica.csv')
df_3.to_csv('iris-virginica.xls')
df_3.to_csv('iris-virginica.txt', sep = ',')

