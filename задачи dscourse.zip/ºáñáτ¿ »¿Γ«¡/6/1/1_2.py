import matplotlib.pyplot as plt
import pandas as pd

df = pd.read_csv('iris.csv')
#print(df.head(10))

var_flower = {'iris-setosa':0, 'iris-versicolor':1, 'iris-virginica':2}

df['species'] = df['species'].map(var_flower)

print(df)